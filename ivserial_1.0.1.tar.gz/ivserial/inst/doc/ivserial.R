## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## -----------------------------------------------------------------------------
library(ivserial)
x <- 100 * diff(log(exchange_rates$China))   # log returns of the yuan
res <- serial_test(x, B = 999, seed = 1, label = "China")
res

## -----------------------------------------------------------------------------
res$p_C                                  # P-value of the combined test C
res$reject                               # decision at level alpha
c(res$p_Q, res$p_P2, res$p_Q_asymptotic) # components, asymptotic P-value of Q
res$cramer_v                             # strength of dependence, 0 to 1
c(res$gamma_hat, res$tau_hat)            # efficiency and its standard deviation
head(res$cells, 4)                       # most over- and under-represented patterns
as.data.frame(res)[, c("label", "n", "p_C", "cramer_v")]   # one row of results

## ----eval = FALSE-------------------------------------------------------------
#  serial_test(exchange_rates$Japan, transform = "logdiff", label = "Japan")  # prices -> log returns
#  serial_test(x, m = 3, d = 4, lags = 3, B = 99999, alpha = 0.01)           # options

## -----------------------------------------------------------------------------
fx <- read_series(system.file("extdata", "exchange_rates.csv", package = "ivserial"))
sc <- screen_series(fx[, c("China", "India", "Japan", "Euro")], transform = "logdiff",
                    B = 999, seed = 1)
sc

## -----------------------------------------------------------------------------
approximate_power(0.13, n = 350, m = 3, d = 4, tau = 1.13)  # ARCH(1); simulated: 0.82
sample_size_table(0.13, m = 3, d = 4, tau = 1.13)
required_sample_size(gamma_from_cramer_v(0.1, 3, 4), m = 3, d = 4, tau = 1)  # from V
choose_resolution(350)

## ----eval = FALSE-------------------------------------------------------------
#  r <- serial_test(pilot, seed = 1)
#  required_sample_size(r$gamma_hat, r$m, r$d, power = 0.8, tau = r$tau_hat)

## -----------------------------------------------------------------------------
null_limit_summary(3, 4)
null_limit_sf(80, m = 3, d = 4)        # asymptotic P-value of Q = 80

## -----------------------------------------------------------------------------
set.seed(3)
y <- arima.sim(list(ar = 0.5), n = 500)
fit <- arima(y, order = c(1, 0, 0))
serial_test(residuals(fit), B = 999, seed = 1)$p_C

